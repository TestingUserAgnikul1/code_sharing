#include "ats_interface.h"

static int g_sock_fd, g_conn_fd;

static struct sockaddr_in servaddr, cliaddr;

/**
 * @brief Start the Interface server socket.
 * 
 * @return int 1/-1 for Success or Failure.
 */
int interface_socket_init(void)
{
    /**< socket create and verification. */
    g_sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    
    if (g_sock_fd == -1)
    {
        printf("socket creation failed...\n");
        return -1;
    }

    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);
    
    int opt = 1;
    if (setsockopt(g_sock_fd, SOL_SOCKET,
                   SO_REUSEADDR | SO_REUSEPORT, &opt,
                   sizeof(opt))) {
        perror("setsockopt");
        return -1;
    }

    // Binding newly created socket to given IP and verification
    if ((bind(g_sock_fd, (struct sockaddr*)&servaddr, sizeof(servaddr))) != 0)
    {
        perror("Bind failed\n");
        return -1;
    }
   
    // Now server is ready to listen and verification
    if ((listen(g_sock_fd, 1)) != 0) {
        printf("Listen failed...\n");
        return -1;
    }

    int len = sizeof(cliaddr);

    g_conn_fd = accept(g_sock_fd, (struct sockaddr*)&cliaddr, &len);
    if (g_conn_fd < 0) {
        perror("server accept failed...\n");
        return -1;
    }
    return 1;
}

int interface_spin(interface_command_t* command)
{  
    if (command == NULL)
    {
        return -1;
    }
    int receievd_bytes = recv(g_conn_fd, (uint8_t*)command, sizeof(interface_command_t), MSG_DONTWAIT);
    
    if (receievd_bytes == sizeof(interface_command_t))
    {
        return 1;
    }
}

