
#ifndef ATS_INTERFACE_H_
#define ATS_INTERFACE_H_

#include <stdio.h>
#include <stdint.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>

#ifdef ATS_MAIN
#define PORT (8001)
#endif

#ifdef ATS_REDUNDANT
#define PORT (8002)
#endif


typedef struct __attribute__((packed))
{
    uint64_t data;
    uint8_t command;
}interface_command_t;

enum
{
    CMD_START_ATS    = 0x0A,
    CMD_STOP_ATS     = 0x0B,
    CMD_HOLD         = 0x1A,
    CMD_RELEASE      = 0x1B,
    CMD_BAD_QUALITY  = 0x2A,
    CMD_GOOD_QUALITY = 0x2B,
};

/**
 * @brief Start the Interface server socket.
 * 
 * @return int 1/-1 for Success or Failure.
 */
int interface_socket_init(void);


int interface_spin(interface_command_t* command);

#endif /* ATS_INTERFACE_H_ */
