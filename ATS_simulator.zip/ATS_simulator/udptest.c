// // Client side implementation of UDP client-server model
// #include <stdio.h>
// #include <stdlib.h>
// #include <unistd.h>
// #include <string.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <arpa/inet.h>
// #include <netinet/in.h>
// #include <stdint.h>
// #include <sys/time.h>
// #include "timers.h"
// #include "threads.h"
// #include "syscall.h"
// #include "stdatomic.h"
// #include "pthread.h"
	
// #define PORT	8101
// #define MAXLINE 1024



// // #define LAUNCH_EPOCH_TIME 1674487800000 /**< 9PM 23-01-2023. */
// //#define LAUNCH_EPOCH_TIME 1674485280000 /**< 8:18 */
// #define LAUNCH_EPOCH_TIME 1674916200000

// static int hold_status = 0;


// typedef struct{
// 	pthread_t pthread_ID;	/*!< Posix thread ID for generated thread */

// 	//Optional Parameters
// 	pid_t kthread_ID;	/*!< Kernel thread ID for generated thread */
// 	char name[20];	/**<Assign this thread a name if scheduled by timer*/

// 	//If used along with a timer
// 	timer_t timer_ID;	/*!< Timer ID used to schedule thread */
// 	struct timespec trig_time; /*!< Interval time for timer trigger */
// }thread_info;


// thread_info thread_id;


// FUNC_STATUS set_procmask(sigset_t* sev, int signum){

// 	/**<Block all signals*/
// 	if(sigfillset(sev) < 0){
// 		PRINT_ERR();
// 		return FAILURE;
// 	}
// 	if(sigprocmask(SIG_BLOCK, sev, NULL) < 0){
// 		PRINT_ERR();
// 		return FAILURE;
// 	}

// 	/**<Block all other signals*/
// 	if(sigemptyset(sev) < 0){
// 		PRINT_ERR();
// 		return FAILURE;
// 	}
// 	/**<Unblock required signal*/
// 	if(sigaddset(sev, signum) < 0) {
// 		PRINT_ERR();
// 		return FAILURE;
// 	}

// //	if(sigprocmask(SIG_UNBLOCK, sev, NULL) < 0){
// //		PRINT_ERR();
// //		return FAILURE;
// //	}
// 	return SUCCESS;
// }

// long long current_timestamp() {
// 	struct timeval te;
// 	gettimeofday(&te, NULL); // get current time.
// 	long long milliseconds = te. tv_sec*1000LL + te. tv_usec/1000; // calculate milliseconds.
// 	return milliseconds;
// }

// uint64_t current_timestamp_us() {
//     struct timeval tv;
//     gettimeofday(&tv,NULL);
//     return tv.tv_sec*(uint64_t)1000000+tv.tv_usec;
// }

// void main_thread(void* unused_param)
// {
// 	time_server_data_t packet;	
	
// 	//servaddr.sin_addr.s_addr = INADDR_ANY;//inet_addr("5.5.5.5");
// 	//servaddr.sin_addr.s_addr = inet_addr("1.1.1.3");
// 	//servaddr.sin_addr.s_addr = inet_addr("1.1.1.45");

// 	// clientaddr.sin_family = AF_INET;
// 	// clientaddr.sin_port = htons(PORT);
// 	// //servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
// 	// //servaddr.sin_addr.s_addr = INADDR_ANY;//inet_addr("5.5.5.5");
// 	//  clientaddr.sin_addr.s_addr = inet_addr("1.1.1.3");

// 	int n, len;
	
// 	packet.UT1.Hdays        =   0b00000001;
// 	packet.UT1.days         =   0b00000010;
// 	packet.UT1.hrs          =   0b00000011;
// 	packet.UT1.mts          =   0b00000101;
// 	packet.UT1.secs         =   0b00010000;
// 	packet.UT1.Hmsecs       =   0b00001000;
// 	packet.UT1.msecs        =   0b10010001;
// 	packet.UT1.qsb          =   0b00000010;
// 	packet.CDT1.hold        =   0b00000000;
// 	packet.CDT1.countstatus =   0b00001001;
// 	packet.CDT1.hrs         =   0b00000111;
// 	packet.CDT1.qsb         =   0b00000010;
// 	uint8_t old_minutes;

	

// 	do{

		

// 	struct timeval current_time;
// 	gettimeofday(&current_time, NULL);
// 	 printf("%d.%d\n", current_time.tv_sec , current_time.tv_usec );
// 	current_time.tv_sec -= EPOCH_START_OF_YEAR;
// 	uint16_t days = current_time.tv_sec/(60*60*24);
// 	current_time.tv_sec %= (60*60*24);
// 	uint16_t hours = current_time.tv_sec/(60*60);
// 	current_time.tv_sec %= (60*60);
// 	uint16_t minutes = current_time.tv_sec/(60);
// 	current_time.tv_sec %= (60);
// 	uint16_t millis = current_time.tv_usec/1000;
	
// 	printf("%d, %d, %d, %d\n", days, hours, minutes, current_time.tv_sec);

// 	packet.UT1.Hdays        =    days/100;
// 	days %= 100;
// 	packet.UT1.days         =    (((days/10)&0x0F)<<4) | (((days%10)&0x0F));
// 	packet.UT1.hrs          =    (((hours/10)&0x0F)<<4) | (((hours%10)&0x0F));
// 	packet.UT1.mts          =    (((minutes/10)&0x0F)<<4) | (((minutes%10)&0x0F));
// 	packet.UT1.secs         =    (((current_time.tv_sec/10)&0x0F)<<4) | (((current_time.tv_sec%10)&0x0F));
// 	packet.UT1.Hmsecs       =    millis/100;
// 	millis %= 100;
// 	packet.UT1.msecs        =    (((millis/10)&0x0F)<<4) | (((millis%10)&0x0F));
	
	
// 	// if (old_minutes != current_time.tv_sec)
// 	// {
// 	// 	old_minutes =  current_time.tv_sec;
// 	// if ((current_time.tv_sec%30)==1)
// 	// {
// 	// 	if (packet.CDT1.hold == 1)
// 	// 	{
// 	// 		packet.CDT1.hold = 0;
// 	// 	}
// 	// 	else if (packet.CDT1.hold == 0)
// 	// 	{
// 	// 		packet.CDT1.hold = 1;
// 	// 	}
// 	// }
// 	// }
// 	packet.CDT1.hold = ((current_time.tv_sec/10)%2);
// 	packet.CDT1.hold = hold_status;


// 	/**< Calculate millis to launch here.*/

// 	gettimeofday(&current_time, NULL);

// 	/**< milli seconds till launch*/
// 	int64_t millis_till_launch = LAUNCH_EPOCH_TIME - (current_time.tv_sec*1000 + current_time.tv_usec/1000);

// 	if (millis_till_launch < 0)
// 	{
// 		packet.CDT1.countstatus = 9;
// 		millis_till_launch = 0 - millis_till_launch;
// 	}
// 	else if (millis_till_launch >= 0)
// 	{
// 		packet.CDT1.countstatus = 50;
// 	}
	
// 	days = millis_till_launch/(24*3600*1000);
// 	millis_till_launch %= (3600000*24);

// 	/**< Extract hours*/
// 	hours = millis_till_launch/(3600*1000);
// 	millis_till_launch %= 3600000;

// 	/**< Extract Minutes */
// 	minutes = millis_till_launch/60000;
// 	millis_till_launch %= 60000;

// 	/**< Extract Seconds*/
// 	uint8_t seconds = millis_till_launch/1000;
// 	millis_till_launch %= 1000;

// 	/**< Milli seconds*/
// 	millis = millis_till_launch;
	
// 	 printf("%d:%d:%d:%d\n", hours, minutes, seconds, millis);
// 	packet.CDT1.hrs          =    (((hours/10)&0x0F)<<4) | (((hours%10)&0x0F));
// 	packet.CDT1.mts          =    (((minutes/10)&0x0F)<<4) | (((minutes%10)&0x0F));
// 	packet.CDT1.secs         =    (((seconds/10)&0x0F)<<4) | (((seconds%10)&0x0F));
// 	packet.CDT1.Hmsecs       =    millis/100;
// 	millis %= 100;
// 	packet.CDT1.msecs        =    (((millis/10)&0x0F)<<4) | (((millis%10)&0x0F));

// 	 printf("%d:%d\n", packet.CDT1.hrs, packet.CDT1.mts);
	
// 	/**< Put timer signal wait here.*/
// 	//if(hold_status==0){
// 	//}
	
// 	}while(1);
	
// 	close(sockfd);
// 	return 0;
// }

// void* input_stdin(void* unUsedParam)
// {
// 	printf("\nstdin started\n");
// 	do
// 	{
// 		char input = getc(stdin);
// 		if (input == -1) continue;
// 		printf("read char = %d", input);
// 		if (input == 'h')
// 		 {
// 			if (hold_status == 1)
// 			{
// 				hold_status = 0;
// 			}
// 			else if (hold_status == 0)
// 			{
// 				hold_status = 1;
// 			}
		
// 		}
		

// 	} while (1);
// }

// // Driver code
// int main() {
	
// 	pthread_create(&thread_id, NULL, main_thread, NULL);
// 	pthread_create(&thread_id, NULL, input_stdin, NULL);
// 	while(1);
// }

