import time
import socket
import struct

def main():
    s = socket.socket()
    s.connect(("", 8001))

    while True:
        data = input()
        if data == "q":
            cmd = struct.pack("=QB", 0, 0x0A)
        if data == "w":
            cmd = struct.pack("=QB", 0, 0x0B)
        elif data == "h":
            cmd = struct.pack("=QB", 0, 0x1A)
        elif data == "r":
            #launchtime =1694183400000
            #cmd=struct.pack("=QB",launchtime,0x1B)
            cmd = struct.pack("=QB", int(time.time()*1000) + 60*1000, 0x1B)
            #print(int(time.time()*1000))
        elif data == "b":
            cmd = struct.pack("=QB", 0, 0x2A)
        elif data == "g":
            cmd = struct.pack("=QB", 0, 0x2B)
        else:
            print(data)
        # for i in cmd:
        #     print(i, end="")
        # print()
        s.send(cmd)


if __name__ == "__main__":
    main()