import time
import struct
import socket
import threading

ATSIP = "1.1.1.1"
ATSPORT = 10069

global s

def read_hold():
    global s
    while True:
        sdata = s.recv(17)
        if len(sdata) == 0:
            break
        print(sdata)
        try:
            unpacked_data = struct.unpack("=BQQ",sdata)
            print(unpacked_data)
        except:
            print("Got", len(sdata), "Bytes")

def send_hold():
    global s
    while True:
        hold_status = input()
        if hold_status == "h":
            packed_data = struct.pack("=B", 1)
            s.send(packed_data)
        if hold_status == "r":
            packed_data = struct.pack("=B", 0)
            s.send(packed_data)

def main():
    global s
    s = socket.socket()
    s.connect((ATSIP, ATSPORT))

    th1 = threading.Thread(target=send_hold)
    th1.start()
    th2 = threading.Thread(target=read_hold)
    th2.start()

    th1.join()
    th2.join()
    

if __name__ == "__main__":
    main()
