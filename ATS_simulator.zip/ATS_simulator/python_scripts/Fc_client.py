import socket
import struct

s=socket.socket()

port=10069

s.connect(('1.1.1.9',port))

while True:
 receive=s.recv(1024)
 data=input()
 if data == "h":
   cmd=struct.pack("=QB",0,0x00)
 elif data == "r":
   cmd=struct.pack("=QB",0,0x01)

 s.send(cmd)
 print (data)