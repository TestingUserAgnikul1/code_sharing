#include <stdio.h>
#include <pthread.h>
#include "ats_interface.h"
#include "udp_sender.h"
#include <sys/time.h>
#include "timers.h"
#include "threads.h"
#include "syscall.h"
#include <signal.h>
#include "stdatomic.h"
#include "pthread.h"

#define EPOCH_START_OF_YEAR 1640995200

#define LAUNCH_EPOCH_TIME 1683828366

static int hold_status = 0;

typedef struct{
	pthread_t pthread_ID;	/*!< Posix thread ID for generated thread */

	//Optional Parameters
	pid_t kthread_ID;	/*!< Kernel thread ID for generated thread */
	char name[20];	/**<Assign this thread a name if scheduled by timer*/

	//If used along with a timer
	timer_t timer_ID;	/*!< Timer ID used to schedule thread */
	struct timespec trig_time; /*!< Interval time for timer trigger */
}thread_info;

static thread_info thread_id;

static sigset_t set;

int signum;

static FUNC_STATUS set_procmask(sigset_t* sev, int signum);

static void* thread_func(void* pUnusedparam);

static int init_timers(void);

uint64_t current_timestamp_us();

int main()
{
	pthread_t pthread_id;
	pthread_create(&pthread_id, NULL, thread_func, NULL);
	pthread_join(pthread_id, NULL);
}


static void* thread_func(void* pUnusedparam)
{
	
	/**< Initialize TCP Server. */
    if (interface_socket_init() == -1)
    {
        printf("Socket Init failed\n");
        return NULL;
    }

    /**< Initialize UDP sender. */
    if (udp_sender_init() == -1)
    {
        printf("UDP sender failed\n");
        return NULL;
    }

    init_timers();

	uint64_t previous_time = current_timestamp_us();
    while (1)
    {
        /**< Spin function. */
        interface_command_t command;
        if (interface_spin(&command) == 1)
        {
            /**< Command came */
            handle_command(command);
        }

        // /**< Send UDP Packet. */
        udp_sender_spin();

        /**< sigwait. */
        if(sigwait(&set, &signum))
        {
			PRINT_ERR("Could not wait on required signal\n");
		}
    }
    return NULL;
}
static int init_timers(void)
{
	signum = SIGRTMIN+10;
	uint64_t period = (uint64_t)(1000000000/100);
	thread_id.trig_time.tv_nsec = period;
	thread_id.trig_time.tv_sec = 0;
	if (thread_id.trig_time.tv_nsec >= 1000000000)
	{
		thread_id.trig_time.tv_nsec = period%1000000000;
		thread_id.trig_time.tv_sec = period/1000000000;
	}
		
	atomic_store(&(thread_id.kthread_ID), syscall(SYS_gettid));

	thread_id.kthread_ID = syscall(SYS_gettid);

	if(thread_id.kthread_ID < 0){
		printf("thread read failed: erro = ", errno);
	}


	if(init_sigthreadtimer(thread_id.kthread_ID, signum, &(thread_id.timer_ID)) < 0){
		printf("init failed: erro = ", errno);
	}

	
	if(start_timer(thread_id.timer_ID, REPEAT, &(thread_id.trig_time)) == FAILURE){
		// pthread_exit(NULL);
		printf("Failed error = %d", errno);
	}

	set_procmask(&set, signum);
}



static FUNC_STATUS set_procmask(sigset_t* sev, int signum)
{

	/**<Block all signals*/
	if(sigfillset(sev) < 0){
		PRINT_ERR();
		return FAILURE;
	}
	if(sigprocmask(SIG_BLOCK, sev, NULL) < 0){
		PRINT_ERR();
		return FAILURE;
	}

	/**<Block all other signals*/
	if(sigemptyset(sev) < 0){
		PRINT_ERR();
		return FAILURE;
	}
	/**<Unblock required signal*/
	if(sigaddset(sev, signum) < 0) {
		PRINT_ERR();
		return FAILURE;
	}

//	if(sigprocmask(SIG_UNBLOCK, sev, NULL) < 0){
//		PRINT_ERR();
//		return FAILURE;
//	}
	return SUCCESS;
}


uint64_t current_timestamp_us() 
{
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv.tv_sec*(uint64_t)1000000+tv.tv_usec;
}