#include "udp_sender.h"
#include <sys/time.h>
#include "timers.h"
#include "ats_interface.h"

#define EPOCH_START_OF_YEAR 1640995200000
#define LAUNCH_EPOCH_TIME   1690036200000

#define ATS_IP_ADDR ("1.1.1.10")
//192.168.0.13
#ifdef ATS_MAIN
#define ATS_PORT    (8101)
#endif

#ifdef ATS_REDUNDANT
#define ATS_PORT    (8102)
#endif

static int g_sock_fd;

static struct sockaddr_in g_servaddr;

static time_server_data_t g_packet = {.CDT1.qsb = 0x02, .UT1.qsb = 0x02};

int start_ats = 0;

int previous_hold_status = 0;

int64_t hold_cdt;

uint64_t g_launch_epoch_time = LAUNCH_EPOCH_TIME;

int udp_sender_init(void)
{
	
	// Creating socket file descriptor
	if ( (g_sock_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
		perror("socket creation failed");
		return -1;
	}
	
	memset(&g_servaddr, 0, sizeof(struct sockaddr_in));
		
	// Filling server information
	g_servaddr.sin_family = AF_INET;
	g_servaddr.sin_port = htons(ATS_PORT);
	g_servaddr.sin_addr.s_addr = inet_addr(ATS_IP_ADDR);

    return 1;
}

int udp_sender_spin(void)
{
	
	struct timeval current_time, temp_time;

	gettimeofday(&current_time, NULL);
	temp_time = current_time;
	current_time.tv_sec -= (EPOCH_START_OF_YEAR/1000);
	uint16_t days = current_time.tv_sec/(60*60*24);

	current_time.tv_sec %= (60*60*24);
	uint16_t hours = current_time.tv_sec/(60*60);

	current_time.tv_sec %= (60*60);
	uint16_t minutes = current_time.tv_sec/(60);

	current_time.tv_sec %= (60);
	uint16_t millis = current_time.tv_usec/1000;
	
	g_packet.UT1.Hdays        =    days/100;
	days %= 100;
	g_packet.UT1.days         =    (((days/10)&0x0F)<<4) | (((days%10)&0x0F));
	g_packet.UT1.hrs          =    (((hours/10)&0x0F)<<4) | (((hours%10)&0x0F));
	g_packet.UT1.mts          =    (((minutes/10)&0x0F)<<4) | (((minutes%10)&0x0F));
	g_packet.UT1.secs         =    (((current_time.tv_sec/10)&0x0F)<<4) | (((current_time.tv_sec%10)&0x0F));
	g_packet.UT1.Hmsecs       =    millis/100;
	millis %= 100;
	g_packet.UT1.msecs        =    (((millis/10)&0x0F)<<4) | (((millis%10)&0x0F));

	current_time = temp_time;
	
	/**< milli seconds till launch*/
	int64_t millis_till_launch = g_launch_epoch_time - (current_time.tv_sec*1000 + current_time.tv_usec/1000);
	if (previous_hold_status != g_packet.CDT1.hold)
	{
		previous_hold_status = g_packet.CDT1.hold;
		if (g_packet.CDT1.hold == 1)
		{
			/**< Store the current CDT*/
			hold_cdt = millis_till_launch;
		}
	}

	if (g_packet.CDT1.hold == 1)
	{
		millis_till_launch = hold_cdt;
	}
	printf("Millis %ld\n", millis_till_launch);

	if (millis_till_launch < 0)
	{
		g_packet.CDT1.countstatus = 9;
		millis_till_launch = 0 - millis_till_launch;
	}
	else if (millis_till_launch >= 0)
	{
		g_packet.CDT1.countstatus = 50;
	}
	
	days = millis_till_launch/(24*3600*1000);
	millis_till_launch %= (3600000*24);

	/**< Extract hours*/
	hours = millis_till_launch/(3600*1000);
	millis_till_launch %= 3600000;

	/**< Extract Minutes */
	minutes = millis_till_launch/60000;
	millis_till_launch %= 60000;

	/**< Extract Seconds*/
	uint8_t seconds = millis_till_launch/1000;
	millis_till_launch %= 1000;

	/**< Milli seconds*/
	millis = millis_till_launch;
	
	g_packet.CDT1.hrs          =    (((hours/10)&0x0F)<<4) | (((hours%10)&0x0F));
	g_packet.CDT1.mts          =    (((minutes/10)&0x0F)<<4) | (((minutes%10)&0x0F));
	g_packet.CDT1.secs         =    (((seconds/10)&0x0F)<<4) | (((seconds%10)&0x0F));
	g_packet.CDT1.Hmsecs       =    millis/100;
	millis %= 100;
	g_packet.CDT1.msecs        =    (((millis/10)&0x0F)<<4) | (((millis%10)&0x0F));

	if (start_ats == 0)
	{
		return 0;
	}

	printf("%02X, %02X, %02X, %02X, %02X, %02X\n",  g_packet.CDT1.hrs,
									g_packet.CDT1.mts,
									g_packet.CDT1.secs,
									g_packet.CDT1.Hmsecs,
									g_packet.CDT1.msecs,
									g_packet.CDT1.qsb
									);

	sendto(g_sock_fd, (const char *)&g_packet, sizeof(g_packet),
		MSG_CONFIRM, (const struct sockaddr *) &g_servaddr,
			sizeof(g_servaddr));
	return 1;
}

int handle_command(interface_command_t command)
{
	switch (command.command)
	{
		case CMD_START_ATS:
		{
			start_ats = 1;
			break;
		}
		case CMD_STOP_ATS:
		{
			start_ats = 0;
			break;
		}
		case CMD_HOLD:
		{
			g_packet.CDT1.hold = 0x01;
			break;
		}
		case CMD_RELEASE:
		{
			g_packet.CDT1.hold = 0x00;
			g_launch_epoch_time = command.data;
			printf("Data = %lu\n", command.data);
			break;
		}
		case CMD_BAD_QUALITY:
		{
			g_packet.CDT1.qsb = 0x09;
			g_packet.UT1.qsb  = 0x09;
			break;
		}
		case CMD_GOOD_QUALITY:
		{
			g_packet.CDT1.qsb = 0x02;
			g_packet.UT1.qsb  = 0x02;
			break;
		}
		default:
		{
			printf("Default case\n"); fflush(stdout);
			exit(0);
			break;
		}
	}
}
