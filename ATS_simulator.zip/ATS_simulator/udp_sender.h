#ifndef UDP_SENDER_H_
#define UDP_SENDER_H_

#include <stdio.h>
#include <stdint.h>
#include <stdint.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include "ats_interface.h"

typedef struct __attribute__((packed))
{
    uint8_t hold;
    uint8_t countstatus;
    uint8_t hrs;
    uint8_t mts;
    uint8_t secs;
    uint8_t Hmsecs;
    uint8_t msecs;
    uint8_t qsb;
}cdt_t;

typedef struct __attribute__((packed))
{
    uint8_t Hdays;
    uint8_t days;
    uint8_t hrs;
    uint8_t mts;
    uint8_t secs;
    uint8_t Hmsecs;
    uint8_t msecs;
    uint8_t qsb;
}ut_t;

typedef struct __attribute__((packed))
{
    uint8_t hrs;
    uint8_t mts;
    uint8_t secs;
}time_display_t;

typedef struct __attribute__((packed))
{
    uint8_t days;
    uint8_t hrs;
    uint8_t mts;
    uint8_t secs;
}days_time_display_t;

typedef struct __attribute__((packed))
{
   uint8_t month;
   uint8_t date;
   uint8_t year_upper;
   uint8_t year_lower;
   uint8_t hours;
   uint8_t minutes;
   uint8_t seconds; 
}gps_date_t;

typedef struct __attribute__((packed))
{
    ut_t UT1;
    cdt_t CDT1;
    ut_t UT2;
    cdt_t CDT2;
    cdt_t CDT3;
    uint8_t reserved_1[18];
    time_display_t CDT1_display;
    time_display_t GMT1_display;
    time_display_t IST1_display;
    days_time_display_t LTGMT16745706000001_display;
    time_display_t CDT2_display;
    time_display_t GMT2_display;
    time_display_t IST2_display;
    days_time_display_t LTGMT2_display;
    uint8_t reserved_2[7];
    uint8_t dummy_1[3];
    uint8_t sample_rate_ID;
    uint8_t sample_rate;
    uint8_t reserved_3[25];
    gps_date_t GPS_date;
    uint8_t reserved_4;
    ut_t GPS;
    uint8_t dummy_2[60];
    uint8_t packet_count_upper_byte;
    uint8_t packet_count_lower_byte;
    uint8_t end_byte;
}time_server_data_t;


int udp_sender_init(void);


int udp_sender_spin(void);


int handle_command(interface_command_t command);

#endif /* UDP_SENDER_H_ */