/**
 ******************************************************************************
 * @file           : timers.c
 * @project        : Agnikul Generic Software Library
 * @brief          : File containing the functions related to timers and time
 *                   in general.
 * @author         : Shawn N, Dheeraj R
 * @version        : v2.0
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) Agnikul Cosmos Private Limited
 * All rights reserved.</center></h2>
 *
 * ****************************************************************************
 */

#include "timers.h"

#define MIN_TIMER_VAL	10000		/**<10us minimum expiration time*/
#define	NSEC_MAX_VAL	999999999	/**<(1 sec - 1) in nsec*/

FUNC_STATUS init_sigtimer(struct sigevent sev, timer_t* timer_id){

	/**<Check for NULL pointers*/
	if(timer_id == NULL){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	/**<Check that the signal number is less than SIGRTMAX and more than SIGRTMIN*/
	if((sev.sigev_signo > SIGRTMAX) | (sev.sigev_signo < SIGRTMIN)){
		PRINT_ERR("Realtime Signal Number is Invalid");
		return FAILURE;
	}

	/**<Creates the timer sourced from the realtime clock*/
	if(timer_create(CLOCK_REALTIME, &sev, timer_id) < 0)
	{
		PRINT_ERR();
		return FAILURE;
	}

	return SUCCESS;
}

FUNC_STATUS init_sigthreadtimer(pid_t thread_id, int signum, timer_t* timer_id){

	struct sigevent sev;	/**<Defines signal to generate on timer expiry*/

	/**<Clear the struct*/
	memset(&sev, 0, sizeof(sev));
	sev.sigev_signo = signum;	/**<Signal number to be generated*/
	sev.sigev_notify = SIGEV_THREAD_ID;	/**<Ensures sigevent like signal is sent
	specifically to the thread mentioned below*/
	sev._sigev_un._tid = thread_id;	/**<Thread to send the signal to*/

	/**<Specify the timer trigger signal settings*/
	if(init_sigtimer(sev, timer_id) == FAILURE){
		return FAILURE;
	}

	return SUCCESS;

}

FUNC_STATUS init_sighandlertimer(void (*timer_handler)(int, siginfo_t*, void*),
		uint8_t signum, timer_t* timer_id){

	/**<Check for NULL pointers*/
	if(timer_handler == NULL){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	struct sigevent sev;		/**<Specifies how the process will be notified
	about the timer expiration event*/
	struct sigaction act;		/**<Specifies action to be taken by process
	when the signal occurs*/

	/**<Define what to do when signum is caught*/
	memset(&act, 0, sizeof(act));
	act.sa_flags = SA_SIGINFO | SA_RESTART;	/**<Modify the behaviour of the signal
	to be caught. Signal handler will accept 3 arguments now and system calls
	associated with the signal handler are restartable*/
	act.sa_sigaction = timer_handler;	/**<Assign the signal handler function
	called when the signal occurs*/
	if (sigaction(signum, &act, NULL) < 0){
		/**<Assign above action settings to signal, the signal number defined by signum.
		 * As a general rule, number of realtime signals available range
		 * between SIGRTMIN to SIGRTMAX. System will throw a run time
		 * error if the number of realtime signals used exceeds SIGRTMAX.*/
		PRINT_ERR();
		return FAILURE;
	}

	/**<Specify the timer trigger signal settings*/
	memset(&sev, 0, sizeof(sev));
	sev.sigev_notify = SIGEV_SIGNAL;	/**<Ensures the process will be notified
	Using a signal handler*/
	sev.sigev_signo = signum;			/**<Signal number*/
	sev.sigev_value.sival_ptr = timer_id;	/**<Passed as a parameter to the
	signal handler used in signal handler to identify which timer triggered the signal*/

	/**<Create the timer*/
	if(init_sigtimer(sev, timer_id) == FAILURE){
		return FAILURE;
	}

	return SUCCESS;
}

FUNC_STATUS init_functhreadtimer(void (*thread_handler)(union sigval sv),
		timer_t* timer_id){

	/**<Check for NULL pointers*/
	if((thread_handler == NULL) | (timer_id == NULL)){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	struct sigevent sev;		/**<Specifies how the process will be
	//notified about the timer expiration event*/
	memset(&sev, 0, sizeof(sev));

	/**<Create the timer event signal*/
	sev.sigev_notify = SIGEV_THREAD;	/**<Specifies that the function mentioned
	//in sigev_notify_function is called as a new thread*/
	sev.sigev_notify_function = thread_handler;	/**<Specifies the function
	//to be run as a thread when the timer expires*/
	sev.sigev_value.sival_ptr = timer_id;	/**<Makes timer_id available as a
	//paramter to the thread created*/
	if (timer_create(CLOCK_MONOTONIC, &sev, timer_id) == -1)	/**<Creates timer
	sourced from Monotonic system clock. This was chosen as unlike the
	realtime clock, it is unaffected by changes in system time*/
	{
		PRINT_ERR("Could not create timer");
		return FAILURE;
	}

	return SUCCESS;
}

FUNC_STATUS start_timer(timer_t timer_id, TIMER_MODE mode, struct timespec* trig_time)
{

	/**<Check for NULL pointer*/
	if(trig_time == NULL){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	/**<Ensure timer nsec provided is above min limits. Min limit set during HIL testing on Rpi.*/
	if((trig_time->tv_sec == 0) & (trig_time->tv_nsec < MIN_TIMER_VAL)){
		PRINT_ERR("Timer nsec value provided is less than 10us\n");
		return FAILURE;
	}

	/**<Ensure timer nsec provided is below max limits*/
	if(trig_time->tv_nsec > NSEC_MAX_VAL){
		PRINT_ERR("Timer nsec value is larger than 1sec. Use sec for seconds\n");
		return FAILURE;
	}

	struct itimerspec itv;	/**<Stores timer trigger configuration values*/
	memset(&itv, 0, sizeof(struct itimerspec));	/**<Clears struct*/

	if(mode == REPEAT){
		itv.it_value = *trig_time;	/**<When started, the timer will expire at this time*/
		itv.it_interval = *trig_time;	/**<Afterwards, the time will expire at
		this time and keep repeating*/
	}else if(mode == ONESHOT){
		itv.it_value = *trig_time;	/**<By only setting this struct,
		timer only runs once till expiration*/
	}

	/**<Arm the timer*/
	if (timer_settime(timer_id, 0, &itv, NULL) < 0)
	{
		PRINT_ERR("Unable to arm timer\n");
		return (FAILURE);
	}

	return (SUCCESS);
}

FUNC_STATUS stop_timer(timer_t timer_id){

	struct itimerspec itv;	/**<Stores timer trigger configuration values*/

	memset(&itv, 0, sizeof(struct itimerspec));	/**<Clears struct
	By setting itv.it_value to 0, the timer is disarmed.*/

	/**<Disarm the timer*/
	if (timer_settime(timer_id, 0, &itv, NULL) == -1)
	{
		PRINT_ERR();
		return FAILURE;
	}

	return SUCCESS;
}

FUNC_STATUS return_counter_time(timer_t timer_id, struct timespec* tim_val){

	/**<Check for NULL pointer*/
	if(tim_val == NULL){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	struct itimerspec itv; /**<Stores current timer values in sec and nsec*/
	memset(&itv, 0, sizeof(struct itimerspec));	/**<Clears struct*/

	/**<Return timer value in struct */
	if(timer_gettime(timer_id, &itv) < 0){
		PRINT_ERR();
		return FAILURE;
	}


	/**<Copy timer value to assigned parameter struct*/
	*tim_val = itv.it_value;

	return SUCCESS;
}



FUNC_STATUS return_timer_overrun(timer_t timer_id, volatile atomic_int_fast64_t* overrun_counter){

	/**<Check for NULL*/
	if(overrun_counter == NULL){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	/**<Access overrun counter*/
	*overrun_counter = timer_getoverrun(timer_id);
	if(*overrun_counter < 0){
		PRINT_ERR();
		return FAILURE;
	}

	return SUCCESS;
}


/**
 * Returns the number of microseconds since UNIX epoch (Jan 1, 1970).
 * @param    None
 * @return    microseconds since epoch in uint64_t
 * */
uint64_t GetuSeconds(void)
{

	struct timespec tms;

	if(clock_gettime(CLOCK_REALTIME, &tms) == -1){
		//perror("clock_gettime()");
		PRINT_ERR();
		return FAILURE;
	}

	uint64_t seconds = (uint64_t)tms.tv_sec;
	uint64_t microseconds = seconds * 1000000;
	uint64_t nano  = (uint64_t)tms.tv_nsec;

	microseconds += nano/1000;
	return microseconds;

}

uint64_t Elapsedtime_us(struct timespec time_prev, struct timespec* time_ret){
	struct timespec time_curr, time_diff;	/**<Init time structs*/

	if(clock_gettime(CLOCK_MONOTONIC, &time_curr) == -1){	/**<get current
		Monotonic time*/
		PRINT_ERR();
		return FAILURE;
	}

	_TIMER_STRUCT_SUB_(&time_curr, &time_prev, &time_diff);	/**<Macro defined
	in timers.h. Returns struct with difference of first 2 parameters*/

	/**<Check that time_prev is less than time_curr, else difference will be negative*/
	if(time_diff.tv_sec < 0 || time_diff.tv_nsec < 0){
		PRINT_ERR("Difference of elapsed time cannot be negative");
		return FAILURE;
	}

	if(time_ret != NULL){	/**<Checks if time_ret is NULL. Should only be NULL
	if user does not want the current monotonic clock returned*/
		memcpy(time_ret, &time_curr, sizeof(struct timespec));
	}

	/**<Return difference in usec*/
	return ((uint16_t)(time_diff.tv_sec*1000000 + time_diff.tv_nsec/1000));
}

/**
 * Gets the current date and time
 * @param    None
 * @return    pointer to the date/time string
 * */
FUNC_STATUS Getlocaltime (char* date){
	//char* date;

	time_t rawtime;
	struct tm * timeinfo;

	if(time(&rawtime) < 0){
		PRINT_ERR();
		return FAILURE;
	}

	timeinfo = localtime(&rawtime);
	if(timeinfo == NULL){
		PRINT_ERR();
		return FAILURE;
	}

	date = asctime(timeinfo);
	if(date  == NULL){
		PRINT_ERR();
		return FAILURE;
	}

	date[strlen(date) - 1] = 0;

	return SUCCESS;

}

FUNC_STATUS return_sys_time(struct tm* sys_time){

	/**<Check for NULL pointer*/
	if(sys_time == NULL){
		PRINT_ERR("NULL pointer detected\n");
		return FAILURE;
	}

	/**<Represents system time as seconds and ns*/
	struct timespec time;
	memset(&time, 0, sizeof(struct timespec));	//clear struct

	/**<Gets system time in seconds and ns*/
	if(clock_gettime(CLOCK_REALTIME, &time) < 0){
		PRINT_ERR();
		return FAILURE;
	}

	/**<Fills tm struct after converting time in seconds to hr, min etc*/
	struct tm* local_time = localtime(&time.tv_sec);
	if(local_time == NULL){
		PRINT_ERR();
		return FAILURE;
	}

	/**<Copy contents of local_time to sys_time*/
	memcpy(sys_time, local_time, sizeof(struct tm));

	return SUCCESS;
}
